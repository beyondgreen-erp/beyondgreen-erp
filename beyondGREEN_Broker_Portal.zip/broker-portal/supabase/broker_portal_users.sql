-- OPTIONAL UPGRADE: per-user logins instead of one shared password.
-- Run this in the Supabase SQL editor only if you want named accounts with
-- individual access control. The shared-password version works without it.

create table if not exists broker_portal_users (
  id          uuid primary key default gen_random_uuid(),
  email       text unique not null,
  full_name   text,
  password_hash text not null,          -- store a bcrypt/argon2 hash, never plaintext
  role        text not null default 'sales',  -- 'sales' | 'broker' | 'admin'
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  last_login  timestamptz
);

-- Lock the table down; only the service role (server-side) may read it.
alter table broker_portal_users enable row level security;

-- No anon/public policies on purpose: all auth checks happen server-side
-- in the /api/broker-portal/login route using the service-role key.

-- To add a user, hash the password in a one-off script:
--   const bcrypt = require('bcryptjs');
--   console.log(bcrypt.hashSync('their-password', 10));
-- then:
-- insert into broker_portal_users (email, full_name, password_hash, role)
-- values ('rep@beyondgreenbiotech.com', 'Sales Rep', '<hash>', 'sales');

-- In the login route, look up by email, compare bcrypt hash, and on success
-- issue the same signed cookie that lib/brokerAuth.ts already creates.
