#!/usr/bin/env bash
# beyondGREEN Broker Portal — one-shot installer.
# Run this from the ROOT of your beyondgreen-erp repo, with the unzipped
# "broker-portal" folder sitting inside it:
#     cd ~/path/to/beyondgreen-erp
#     bash broker-portal/install_broker_portal.sh
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "→ Checking this is a Next.js repo..."
if [ ! -f package.json ]; then echo "✗ No package.json here. cd into your ERP repo first."; exit 1; fi

echo "→ Copying portal files into place..."
mkdir -p lib data app/broker-portal/login app/api/broker-portal/login app/api/broker-portal/logout supabase
cp "$SRC/lib/brokerEngine.ts"  lib/
cp "$SRC/lib/brokerAuth.ts"    lib/
cp "$SRC/data/brokerSkuData.json" data/
cp "$SRC/app/broker-portal/page.tsx"            app/broker-portal/
cp "$SRC/app/broker-portal/PortalClient.tsx"    app/broker-portal/
cp "$SRC/app/broker-portal/login/page.tsx"      app/broker-portal/login/
cp "$SRC/app/api/broker-portal/login/route.ts"  app/api/broker-portal/login/
cp "$SRC/app/api/broker-portal/logout/route.ts" app/api/broker-portal/logout/
cp "$SRC/supabase/broker_portal_users.sql"      supabase/

echo "→ Handling middleware..."
if [ -f middleware.ts ]; then
  echo "  ⚠ You already have a middleware.ts. NOT overwriting it."
  echo "    Open broker-portal/middleware.ts and merge its matcher + auth check into your existing one."
else
  cp "$SRC/middleware.ts" middleware.ts
  echo "  ✓ Added middleware.ts"
fi

echo "→ Checking tsconfig path alias..."
if ! grep -q '"@/\*"' tsconfig.json 2>/dev/null; then
  echo "  ⚠ Couldn't confirm the '@/*' path alias in tsconfig.json."
  echo "    Make sure compilerOptions has:  \"baseUrl\": \".\", \"paths\": { \"@/*\": [\"./*\"] }"
else
  echo "  ✓ '@/*' alias present"
fi

echo "→ Generating a cookie secret for you to paste into Vercel..."
SECRET=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))" 2>/dev/null || openssl rand -hex 48)
echo ""
echo "==================== COPY THESE INTO VERCEL ===================="
echo "BROKER_PORTAL_SECRET = $SECRET"
echo "BROKER_PORTAL_PASSWORD = <pick a password for your sales team>"
echo "==============================================================="
echo ""

echo "→ Committing and pushing..."
git add lib/brokerEngine.ts lib/brokerAuth.ts data/brokerSkuData.json app/broker-portal app/api/broker-portal supabase/broker_portal_users.sql middleware.ts 2>/dev/null || git add -A
git commit -m "Add broker & sales portal" || echo "  (nothing to commit)"
git push && echo "  ✓ Pushed — Vercel will start building." || echo "  ⚠ Push failed; run 'git push' manually."

echo ""
echo "DONE on the code side. Last 2 steps (only you can do these):"
echo "  1. Vercel → beyondgreen-erp → Settings → Environment Variables → add the two above → Save"
echo "  2. Deployments → latest → Redeploy"
echo "Then open  /broker-portal  and log in."
