// beyondGREEN Broker Portal — route protection
// NOTE: If your ERP already has a middleware.ts at the repo root, MERGE this
// matcher/logic into it rather than overwriting. This guards /broker-portal/*
// and redirects unauthenticated users to the login page.

import { NextRequest, NextResponse } from "next/server";
import { verifyToken, SESSION_COOKIE } from "@/lib/brokerAuth";

export const config = {
  matcher: ["/broker-portal/:path*"],
};

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow the login page through.
  if (pathname.startsWith("/broker-portal/login")) {
    return NextResponse.next();
  }

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const secret = process.env.BROKER_PORTAL_SECRET || "";
  const ok = await verifyToken(token, secret);

  if (!ok) {
    const url = req.nextUrl.clone();
    url.pathname = "/broker-portal/login";
    url.searchParams.set("from", pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
