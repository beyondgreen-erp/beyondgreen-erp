# beyondGREEN — Broker & Sales Portal

A password-protected pricing portal that drops into your existing beyondGREEN ERP
(Next.js 14 App Router + Supabase, on Vercel). Your sales team logs in and gets the
full landed-cost engine, margin grid, China-vs-India cost edge, and a bid-to-win
calculator — without seeing the rest of the ERP and without touching the spreadsheet.

Lives at **`/broker-portal`**. Login at **`/broker-portal/login`**.

---

## What's included

```
lib/brokerEngine.ts                     landed-cost engine (mirrors the Excel ENGINE tab)
lib/brokerAuth.ts                       HMAC-signed session cookie helpers
data/brokerSkuData.json                 all 789 SKUs + engine rates (exported from the workbook)
middleware.ts                           protects /broker-portal/* (merge into existing middleware if you have one)
app/broker-portal/page.tsx              server component, re-checks the session
app/broker-portal/PortalClient.tsx      the portal UI (table, filters, calculator drawer)
app/broker-portal/login/page.tsx        login screen
app/api/broker-portal/login/route.ts    verifies the password, sets the cookie
app/api/broker-portal/logout/route.ts   clears the session
.env.broker.example                     the two env vars you must set
supabase/broker_portal_users.sql        OPTIONAL: per-user accounts instead of one shared password
```

## Install (about 10 minutes)

1. **Copy the files** into your ERP repo, preserving these paths. `lib/`, `data/`,
   `app/broker-portal/`, and `app/api/broker-portal/` sit alongside what you already have.

2. **`@/` path alias** — the imports use `@/lib/...` and `@/data/...`. If your
   `tsconfig.json` already maps `"@/*": ["./*"]` (most Next.js apps do), you're set.
   Otherwise add under `compilerOptions`:
   ```json
   "baseUrl": ".",
   "paths": { "@/*": ["./*"] }
   ```

3. **Middleware** — if you already have a `middleware.ts` at the repo root, **merge**
   the matcher and the auth check from this one into it (don't overwrite). If you don't,
   just drop this file in.

4. **Set the two env vars** (see `.env.broker.example`):
   - `BROKER_PORTAL_PASSWORD` — the password the team types in.
   - `BROKER_PORTAL_SECRET` — a long random string for signing cookies. Generate with
     `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.

   Add both to `.env.local` for local dev and to **Vercel → Settings → Environment
   Variables** for production. Redeploy after adding them.

5. **Run it.** `npm run dev`, visit `/broker-portal`, you'll be sent to the login,
   enter the password, and you're in.

## How the numbers work

The engine is a faithful copy of the workbook's **LANDED COST ENGINE** tab:

`landed = FOB + origin inland + ocean + drayage + base duty + AD/CVD + customs fees`

- Freight is allocated per case by cubic feet (usable container volume ÷ case cu ft).
- USA-origin items pay none of the import lines.
- AD/CVD only applies to in-scope items (paper bags **with handles**); the calculator
  recomputes live when a rep switches origin, so they can see the China-vs-India gap.
- The drawer also shows what a China-sourced competitor would pay, your cost edge,
  the 8-tier margin grid, and a bid-to-win price with the resulting margin.

All rates sit in `data/brokerSkuData.json` under `engine`. To update freight or duties,
edit that object once and redeploy — or wire it to a live feed (below).

## Keeping rates current (the "every 48 hours" ask)

Static numbers don't refresh themselves. Two clean options once this is hosted:

- **Manual, single edit:** change the `engine` block in `brokerSkuData.json`, commit, redeploy.
- **Live, automatic:** move the `engine` object into a Supabase table and add a Vercel
  Cron job (every 48h) that pulls current ocean/tariff rates from an API (e.g. Freightos)
  and updates the row. The portal reads rates server-side on each load, so it would always
  show current numbers. This is the real version of auto-refresh — happy to build it next.

## Upgrading to per-user logins

The shared password is the fastest path. For named accounts with individual on/off
control, run `supabase/broker_portal_users.sql`, store bcrypt password hashes, and look
users up in the login route before issuing the same signed cookie. Notes are in the SQL file.

## Security notes

- The session cookie is HTTP-only, signed (HMAC-SHA256), and expires after 12 hours.
- Middleware blocks every `/broker-portal/*` route; the page also re-verifies server-side.
- Pricing is confidential — the footer reminds the team not to share it externally.
- AD/CVD is **producer-specific**; confirm beyondGREEN Paras's exact India rate and all
  tariffs with your customs broker before quoting real bids.
